#ifndef PHYSICS_H_INCL
#define PHYSICS_H_INCL

#include <btBulletDynamicsCommon.h>
#include "CPhysicsWorld.h"
#include "CPhysicsObject.h"

#endif