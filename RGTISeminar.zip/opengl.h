#ifndef OPENGL_H_INCL
#define OPENGL_H_INCL

#include <Windows.h>
#include <GL\glew.h>
#include <gl\freeglut.h>

#endif